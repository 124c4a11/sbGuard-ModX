<?php
require_once (dirname(__DIR__) . '/mslink.class.php');
class msLink_mysql extends msLink {}